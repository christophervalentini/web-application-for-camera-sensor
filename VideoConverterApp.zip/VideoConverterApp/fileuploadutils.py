import os,shutil,logging,configimpl,json
# from time import gmtime, strftime
import time


# configuration for using pyserver.flowjs in windows o linux
# where to change the path separator
folderlike=configimpl.config.get('fileconfig','folderlike')
# path where to save the file
tmppath=configimpl.config.get('fileconfig','tmppath')
uploadpath=configimpl.config.get('fileconfig','uploadedpath')


def cleantmp(arg0):
    logging.info('cleaning')
    try:
        logging.info('start cleaning the %s folder' % arg0);
        for f in os.listdir(arg0):
            os.remove(arg0+configimpl.config.get('fileconfig','folderlike')+f)
        os.rmdir(arg0)
    except:
        logging.info("Exception  while removing %s " % arg0)
        logging.exception("message")


def createFileFromChunk(filename,chunksize,totalsize,flowTotalChunks):
        total_files=0
        temp_dest = tmppath + str(filename) + configimpl.config.get('fileconfig','folderlike')
        logging.info('total chunks is %s' % flowTotalChunks)
        try:
            if not os.path.exists(temp_dest):
                os.makedirs(temp_dest)
            for f in os.listdir(temp_dest):
                if f.index(filename)!=-1:
                    total_files=total_files+1
            if total_files<1:
                return 'UPLOAD'
        except:
            logging.exception("message")
        logging.info('total files %s ' % str(total_files) )
        if(total_files==1 and int(flowTotalChunks)==1):
            try:
                logging.info('upload path from config %s ' % uploadpath)
                logging.info('completing file %s ' % uploadpath+filename)
                f=open(uploadpath+filename,'wb+')
                newFile=temp_dest+filename+'.'+'part1'
                file=open(newFile,'rb')
                try:
                    f.write(file.read())
                except:
                    logging.exception("message")
                file.close()
                f.close()
                logging.info('the total chunks is %s' %str(flowTotalChunks))
                logging.info('in temp_dest folder there is %s chunk'%str(total_files))
            except:
                logging.exception("message")
            cleantmp(temp_dest)
        # total_files * int(chunksize))>=(int(totalsize)-int(chunksize) + 1
        # this maybe the real check to do
        elif(str(total_files)==flowTotalChunks):
            logging.info('Merging file')
            f=open(uploadpath+filename,'wb')
            logging.info('ending file %s ' % f)
            for i in range(1,total_files+1):
                newFile=temp_dest+filename+'.'+'part'+str(i)
                logging.info('reading new file %s' % newFile)
                file=open(newFile,'rb')
                try:
                    f.write(file.read())
                except:
                    logging.exception("message")
                    file.close()
                logging.info('the total chunks is %s' %str(flowTotalChunks))
                logging.info('in temp_dest folder there is %s chunk'%str(total_files))
            f.close()
            cleantmp(temp_dest)
        else:
            return 'UPLOAD'


def chunkOperationUtil(request,response):
        flowFileName=None
        flowChunkSize=None
        flowTotalSize=None
        flowChunkNumber=None
        responseTotalChunks=None
        flowFileIdentifier=None
        if (request.method == 'GET'):
            #check the validity of the file
            logging.info("file checking")
            flowChunkSize=str(request.args.get('flowChunkSize'))
            flowFileName=str(request.args.get('flowFilename'))
            flowFileIdentifier=str(request.args.get('flowIdentifier'))
            flowFileIdentifier=str(time.time())
            flowTotalSize=str(request.args.get('flowTotalSize'))
            flowTotalChunks=str(request.args.get('flowTotalChunks'))
            flowChunkNumber=str(request.args.get('flowChunkNumber'))
            responseTotalChunks={'totalchunks':flowTotalChunks}
            n = json.dumps(responseTotalChunks)
            response.name=flowFileIdentifier
            response.data=n
            response.status='400'
        elif (request.method == 'POST'):
            flowChunkNumber=str(request.form['flowChunkNumber'])
            flowChunkSize=str(request.form['flowChunkSize'])
            flowFileName=request.form['flowFilename']
            #extract extension
            filename_part, file_extension_part = os.path.splitext(flowFileName)
            #unique file identifier used on server
            # flowFileIdentifier = request.form['flowIdentifier'] + file_extension_part            
            flowFileIdentifier=str(time.time())
            flowTotalSize=str(request.form['flowTotalSize'])
            flowTotalChunks=str(request.form['flowTotalChunks'])
            response.status="200"
            #if the file already exists do not upload
            if not os.path.isfile(uploadpath+configimpl.config.get('fileconfig','folderlike')+flowFileIdentifier):
                logging.info('uploading file %s \n file info: flowchuncknumber = %s; flowchunksize = %s; flowtotalsize = %s;' % (flowFileIdentifier, flowChunkNumber, flowChunkSize, flowTotalSize))
                logging.info('creating folder')
                createTempFile(flowFileIdentifier,flowChunkNumber,request.files['file'].read())
                logging.info("Building file")
                createFileFromChunk(flowFileIdentifier,flowChunkSize,flowTotalSize,flowTotalChunks)
            #if now the file exist and we are at the last chunk...
            if os.path.isfile(uploadpath+configimpl.config.get('fileconfig','folderlike')+flowFileIdentifier) and flowChunkNumber == flowTotalChunks:
                logging.info("File transfer completed or file already present in upload folder")
                path=str(uploadpath+flowFileIdentifier)
                responseTotalChunks={'msg':'file upload complete','address':path,'filename':flowFileIdentifier}
            else:
                responseTotalChunks={'msg':'file not yet completed'}
                logging.info('file not yet completed %s ' % str(flowChunkNumber))
            n = json.dumps(responseTotalChunks)
            response.data=n
            response.name=flowFileIdentifier


def createTempFile(flowFileName,flowChunkNumber,chunk):
    try:
        temp_dest = tmppath + str(flowFileName) + configimpl.config.get('fileconfig','folderlike')
        logging.info('create %s '% temp_dest)
        os.makedirs(temp_dest)
    except:
        logging.info(" %s allready exists" % temp_dest)
    chunk_file = str(flowFileName)+'.part'+str(flowChunkNumber)
    chunkpath=temp_dest+chunk_file
    try:
        chunkFile=open(chunkpath,'wb')
        chunkFile.write(chunk)
        chunkFile.close()
        logging.info('file completed name is %s ' % chunkpath)
    except:
        logging.exception("message")
