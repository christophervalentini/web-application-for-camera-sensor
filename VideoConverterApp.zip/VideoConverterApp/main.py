import configimpl
import json
import logging
import multiprocessing
import os
import schedule
import shutil
import signal
import sys
import time
import gc

from flask import render_template, url_for, redirect, Flask, request, Response, current_app
from flask_cors import CORS, cross_origin
from werkzeug import security

import opencvjob
from fileuploadutils import chunkOperationUtil

app = Flask(__name__)
CORS(app)
# file where to find the log configurations
logging.basicConfig(filename=configimpl.config.get('fileconfig', 'logpath'), level=logging.INFO)
# path where file will be saved
uploadpath = configimpl.config.get('fileconfig', 'uploadedpath')
tmppath = configimpl.config.get('fileconfig', 'tmppath')

# List for process management
process_list = list()
scheduler_process = None


# function for process execution
def run_process(fileName, fileNameDest):
    # time.sleep(5)
    esit = opencvjob.opencv_job(fileName, fileNameDest)
    return esit


# function for process execution with parameters
def run_process(fileName, fileNameDest, inputParameter):
    # time.sleep(5)
    esit = opencvjob.opencv_job(fileName, fileNameDest, inputParameter)
    return esit


# Function old files remover
def remove_old_files():
    print("Removing old files - Job started")
    logging.info("Removing old files - Job started")
    current_time = time.time()
    # first delete old files in uploaded directory
    source = "./static/uploaded"
    onlyfiles = [f for f in os.listdir(source) if os.path.isfile(os.path.join(source, f))]  # list of filenames
    files_todelete_paths = [source + os.sep + onlyfile for onlyfile in onlyfiles]
    for f in files_todelete_paths:
        creation_time = os.path.getctime(f)
        if (current_time - creation_time) // 3600 > 24:  # older file created >24h before
            try:
                os.unlink(f)
            except:
                pass  # if impossible to delete go ahead
    # delete files and folders (also not empty) in tmpdir directory, if there are residuals
    source = "./static/tmpdir"
    onlyfiles = [f for f in os.listdir(source) if os.path.isfile(os.path.join(source, f))]  # list of filenames
    onlyfolders = [d for d in os.listdir(source) if not os.path.isfile(os.path.join(source, d))]  # list only folders
    # delete temp files if any (and old)
    files_todelete_paths = [source + os.sep + onlyfile for onlyfile in onlyfiles]
    for f in files_todelete_paths:
        creation_time = os.path.getctime(f)
        if (current_time - creation_time) // 3600 > 24:  # older file created >24h before
            try:
                os.unlink(f)
            except:
                pass  # if impossible to delete go ahead
    # delete folders and its files if old folders
    folders_todelete_paths = [source + os.sep + onlyfolder for onlyfolder in onlyfolders]
    for d in folders_todelete_paths:
        creation_time = os.path.getctime(d)
        if (current_time - creation_time) // 3600 > 24:  # older folder created >24h before
            try:
                shutil.rmtree(d, True)
            except:
                pass  # if impossible to delete go ahead


# Function for garbage remover scheduler
def sched_process(args):
    # Execute cleanup every day
    print("Starting Scheduler process... Remove old files (>24h) every day")
    logging.info("Starting Scheduler process... Remove old files (>24h) every day")
    schedule.every().day.do(remove_old_files)
    while True:
        schedule.run_pending()
        time.sleep(30)


@app.route('/')
def index():
    return redirect(url_for('static', filename='index.html'))


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    resp = Response()
    chunkOperationUtil(request, resp)
    decoded_resp = json.loads(resp.data)
    if decoded_resp != None:
        if 'address' in decoded_resp:
            print("Downloaded file " + decoded_resp['address'])
            # print("Filename is " + decoded_resp['filename'])
    return resp


@app.route('/startconv', methods=['POST'])
def startconv():
    global process_list
    data = json.loads(request.data.decode())
    rel_filepath = data['rel_filepath']
    parameter = data['parameter']
    parameterconv = str(parameter)
    
    print('Selected value: ' + str(parameter))
    print('Starting conversion for file: ' + rel_filepath)
    logging.info('parameter: ' + parameterconv)
    logging.info('Starting conversion for file: ' + rel_filepath)
    conv_rel_filepath = rel_filepath + '-processed' + '.webm'
    # FOR DEBUG NOW PASSING THE ORIGINAL FILE
    # conv_rel_filepath = rel_filepath
    # create a new process
    # Conversion with parameters:
    p = multiprocessing.Process(target=run_process, args=(rel_filepath, conv_rel_filepath, parameter))
    p.debug = False
    p.reloader = False
    # run the process
    p.start()
    time.sleep(2)  # sleep a while and then in case check if there is an error in the conversion
    if p.is_alive():
        # add the process to the list
        process_list.append({
            'process': p,
            'pid': str(p.pid),
            'converted_rel_filepath': conv_rel_filepath
        })
        resp = json.dumps({'msg': 'conversion started', 'rel_filepath': rel_filepath, 'jobid': str(p.pid)})
    else:
        resp = json.dumps({'msg': 'conversion error', 'rel_filepath': rel_filepath, 'jobid': str(p.pid)}), 202
    return resp


@app.route("/convstatus/<job_key>", methods=['GET'])
def get_status(job_key):
    global process_list
    # fetch the process corresponding to given id
    p_dic_list = [process_dic for process_dic in process_list if process_dic['pid'] == str(job_key)]
    if len(p_dic_list) == 0:
        resp = json.dumps({'msg': 'conversion error', 'rel_filepath': '', 'jobid': ''})
        return resp
    p_dic = p_dic_list[0]
    p = p_dic['process']
    # check if job is finished
    if (not p.is_alive()):
        # check conversion details
        conv_rel_filepath = p_dic['converted_rel_filepath']
        print("Conversion completed! New file path is " + conv_rel_filepath)
        logging.info("Conversion completed! New file path is " + conv_rel_filepath)
        resp = json.dumps({'msg': 'conversion completed', 'rel_filepath': conv_rel_filepath, 'jobid': str(p.pid)})
        # remove from process list
        process_list.remove(p_dic)
        return resp
    else:
        resp = json.dumps({'msg': 'conversion not finished', 'rel_filepath': '', 'jobid': str(p.pid)})
        return resp, 202


def Exit_gracefully(signal, frame):
    # Put here closing threads
    try:
        scheduler_process.terminate()
    except:
        pass
    for proc_dic in process_list:
        try:
            proc_dic['process'].terminate()
        except:
            pass
    print("\nExiting App...")
    gc.collect()

    sys.exit(0)


# Main function
def main():
    # manage ctrl+c signal
    signal.signal(signal.SIGINT, Exit_gracefully)
    # call the cleanup file function once after start
    remove_old_files()
    # Create process for sheduler (remove old files)
    global scheduler_process
    scheduler_process = multiprocessing.Process(target=sched_process, args=('',))
    if not scheduler_process.is_alive():
        scheduler_process.debug = False
        scheduler_process.reloader = False
        scheduler_process.start()
    # Start FLASK webserver
    print("Starting webserver:  http://127.0.0.1:" + str(configimpl.config.getint('flask', 'port')))
    app.debug = configimpl.config.getboolean('flask', 'debug')
    app.run(host=configimpl.config.get('flask', 'host'), port=configimpl.config.getint('flask', 'port'))


if __name__ == '__main__':
    main()
