import numpy as np
import cv2
import time 

fileName='static/uploaded/example.avi'  # change the file name if needed
fileNameDest='static/uploaded/example.avi-conv.webm'
# 


# Edge Detection Parameter
parameter1=20
parameter2=60
intApertureSize=1
kernelSize=1   # Kernel Bluring size

cap = cv2.VideoCapture(fileName)          # load the video
# If i can open the video, then extract useful information
if cap.isOpened():
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH ))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT ))
    fps =  int(cap.get(cv2.CAP_PROP_FPS))
    print(f"{width} {height} {fps}")
    imgSize = (width, height)
    fourcc = cv2.VideoWriter_fourcc(*"VP80")
    writer = cv2.VideoWriter(fileNameDest, fourcc, fps, imgSize, False)
    while(cap.isOpened()):
        ret, frame = cap.read()
        if ret==True:
            frame = cv2.GaussianBlur(frame, (kernelSize,kernelSize), 0, 0)
            frame = cv2.Canny(frame,parameter1,parameter2,intApertureSize)  # Canny edge detection
            writer.write(frame)                   # save the frame into video file
            cv2.imshow('Video Capture',frame)     # show on the screen
            if cv2.waitKey(1) & 0xFF == ord('q'): # press q to quit
                break
        else:
            break
else:
    print("Can not open video")
# while(cap.isOpened()):                    # play the video by reading frame by frame
#     ret, frame = cap.read()
#     if ret==True:
#         # optional: do some image processing here 
    
#         cv2.imshow('frame',frame)              # show the video
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break
#     else:
#         break
writer.release()
cap.release()
cv2.destroyAllWindows()