#!/bin/bash
echo "Loading Webapp"
cd ./VideoConverterApp
python3 main.py
