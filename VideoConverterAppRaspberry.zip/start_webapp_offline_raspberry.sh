#!/bin/bash
echo "Loading Webapp"
cd ./VideoConverterAppRaspberry
python3 main.py
