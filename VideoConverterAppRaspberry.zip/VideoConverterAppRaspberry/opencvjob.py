import numpy as np
import cv2
import time

# import glob
# import os, sys
# PBP ALGORITHM
# Date: 25/1/2019
# Last change: 25/1/2019
# Nbit: number of bits used to execute the algorithm

def opencv_job(fileName, fileNameDest, inputParameter):
    cap = cv2.VideoCapture(fileName)  # load the video
    # If i can open the video, then extract useful information

    # initialization
    Nbit = inputParameter  # number of bits of the ADC
    Res = 8  # bit resolution
    DN = 2 ** Nbit  # Digital Numbers
    FS = DN - 1  # Full Scale
    Nmask = Res - Nbit
    TH = DN - 1  # Threshold High
    TL = 1  # Threshold Low
    #
    webcam_framerate = 0

    if cap.isOpened():
        cols = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        rows = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        colsFull = 2 * cols
        rowsFull = rows
        fps = webcam_framerate
        ret, borig  = cap.read()
        borig       = cv2.cvtColor(borig, cv2.COLOR_BGR2GRAY)
        #
        if webcam_framerate == 0:
            fps = int(cap.get(cv2.CAP_PROP_FPS))
        imgSize = (cols, rows)
        imgSizeFull = (colsFull, rowsFull)
        fourcc = cv2.VideoWriter_fourcc(*"VP80")  # output as webm with codev VC8
        writer = cv2.VideoWriter(fileNameDest, fourcc, fps, imgSizeFull, False)
        # create numpy array
        x           = np.arange(cols*rows)
        x           = x.reshape(rows, cols)
        mask        = np.zeros_like(x)
        bret        = np.zeros_like(x) # retrieved image
        bf          = np.zeros_like(x)
        bi          = np.zeros_like(x)
        bfoldsym    = np.zeros_like(x)
        Full = np.zeros((rows, 2 * cols), np.uint8)
        # end create numpy array
        # Do conversion using PBP algorithm
        while cap.isOpened():
            ret, frame = cap.read()
            # print(ret)
            if ret:
                image = frame
                image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                image = image.astype(np.uint8)
                # Generate HOT-PIXELS (HOT) nel quadrante superiore
                borig = image
                b = (borig/(2**mask))
                b = b.astype(np.uint8)
                bi = b
                bi = bi.astype(np.uint8)

                # frame clamping [0, TH] as the ADC does
                tmp     = b > TH
                b[tmp]  = TH
                tmp     = b < TL
                b[tmp]  = 0

                tmp             = (mask == 0)
                bf[tmp]         = b[tmp]
                bfoldsym[tmp]   = b[tmp]
                bret[tmp]       = b[tmp].astype(np.uint8)
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 0)
                tmp1            = (mask < 2)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = (FS-1) - (b[tmp] - DN/2)
                bret[tmp]       = (DN + 2*(bf[tmp] - DN/2))
                bret = bret.astype(np.uint8)

                tmp0            = (mask > 1)
                tmp1            = (mask < 3)
                tmp             = (tmp0 & tmp1)
                bfoldsym[tmp]   = b[tmp]
                bf[tmp]         = b[tmp].astype(np.uint8)
                bret[tmp]       = 2*(DN + 2*(bf[tmp] - DN/2))
                bret = bret.astype(np.uint8)

                tmp0            = (mask > 2)
                tmp1            = (mask < 4)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = (FS-1) - (b[tmp] - DN/2)
                bret[tmp]       = 4*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 3)
                tmp1            = (mask < 5)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = b[tmp]
                bret[tmp]       = 8*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 4)
                tmp1            = (mask < 6)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = (FS-1) - (b[tmp] - DN/2)
                bret[tmp]       = 16*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 5)
                tmp1            = (mask < 7)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = b[tmp]
                bret[tmp]       = 32*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 6)
                tmp1            = (mask < 8)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = (FS-1) - (b[tmp] - DN/2)
                bret[tmp]       = 64*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 7)
                tmp1            = (mask < 9)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = b[tmp]
                bret[tmp]       = 128*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 8)
                tmp1            = (mask < 10)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = (FS-1) - (b[tmp] - DN/2)
                bret[tmp]       = 256*(DN + 2*(bf[tmp] - DN/2))
                bret            = bret.astype(np.uint8)

                tmp0            = (mask > 9)
                tmp1            = (mask < 11)
                tmp             = (tmp0 & tmp1)
                bf[tmp]         = b[tmp].astype(np.uint8)
                bfoldsym[tmp]   = b[tmp]
                bret[tmp]       = 512*(DN + 2*(bf[tmp] - DN/2))

                tmp = bret > 255
                bret[tmp] = 255
                tmp = bret < 1
                bret[tmp] = 0

                bret = bret.astype(np.uint8)
                bfoldsym = bfoldsym.astype(np.uint8)

                # Start update mask
                tmp = bi > TH
                mask = mask + 1*tmp
                tmp = mask > Nmask
                mask[tmp] = Nmask
                tmp = bi < TL
                mask = mask - 1*tmp
                tmp = mask <= 0
                mask[tmp] = 0
                mask = 1*mask.astype(np.uint8)
                # End update mask

                Full = cv2.hconcat((borig, bret))
                Full = Full.astype(np.uint8)
                writer.write(Full)  # save the frame into video file
                #
            else:
                # End of file
                writer.release()
                cap.release()
                print("End of conversion")
                return True
    else:
        cap.release()
        print("Can not open video")
        return False


if __name__ == "__main__":
    imgsPath1  ='/Users/max/WORK/BENCHMARK/REPOSITORY/esempi/gray1.avi'
    imgsPath2  ='/Users/max/WORK/BENCHMARK/REPOSITORY/esempi/gray2.avi'
    imgsPath3  ='/Users/max/WORK/BENCHMARK/REPOSITORY/FORENSOR/bpb_day_190331_07.5.avi'
    imgsPath4  ='/Users/max/WORK/BENCHMARK/REPOSITORY/FORENSOR/Active example movie.avi'
    imgsPath5  ='/Users/max/WORK/BENCHMARK/ANNO2012/nvidia20121213/Katerina/marlin/marlinKaterina.avi'
    imgsPath6  ='/Users/max/WORK/BENCHMARK/ANNO2012/yogurt20122107/scene1_marlin/yogurt.avi'
    imgsPath7  ='/Users/max/WORK/BENCHMARK/ANNO2019/20190106_120945.mp4'
    imgsPath8  ='/Users/max/WORK/BENCHMARK/ANNO2019/20190106_121106.mp4'
    imgsPath9  ='/Users/max/WORK/BENCHMARK/ANNO2019/20190106_121224.mp4'
    imgsPath10 ='/Users/max/WORK/BENCHMARK/ANNO2019/20190106_121320.mp4'
    opencv_job(imgsPath1, "output_0.webm")  # se uso la webcam: opencv_job(0, "output.webm")
